function normalizeCode(value){
  return value.trim().toUpperCase().replace(/\s+/g,"");
}
function formatNumber(value){
  const n=Number(value);
  if(!Number.isFinite(n)) return value==="" ? "0" : String(value);
  return n.toLocaleString("vi-VN");
}
function getNumber(value){
  const n=Number(value);
  return Number.isFinite(n)?n:0;
}
function showMessage(text){
  document.getElementById("message").textContent=text||"";
}
function renderEmployee(emp){
  document.getElementById("rCode").textContent=emp.maNhanVien;
  document.getElementById("rName").textContent=emp.hoTen||"—";
  document.getElementById("rKh").textContent=emp.khXapCa||"—";
  document.getElementById("rHas").textContent=formatNumber(emp.coPhuCap);
  document.getElementById("rSpecial").textContent=formatNumber(emp.pcDacThu);
  document.getElementById("rViva").textContent=formatNumber(emp.pcBocBinhViva);
  const total=getNumber(emp.coPhuCap)+getNumber(emp.pcDacThu)+getNumber(emp.pcBocBinhViva);
  document.getElementById("rTotal").textContent=formatNumber(total);
  document.getElementById("result").classList.remove("hidden");
}
document.getElementById("searchForm").addEventListener("submit",function(e){
  e.preventDefault();
  const code=normalizeCode(document.getElementById("employeeCode").value);
  showMessage("");
  if(!code){
    document.getElementById("result").classList.add("hidden");
    showMessage("Vui lòng nhập mã nhân viên.");
    return;
  }
  const employee=EMPLOYEES.find(x=>normalizeCode(x.maNhanVien)===code);
  if(!employee){
    document.getElementById("result").classList.add("hidden");
    showMessage("Không tìm thấy mã nhân viên. Vui lòng kiểm tra lại.");
    return;
  }
  renderEmployee(employee);
});
document.getElementById("clearBtn").addEventListener("click",function(){
  document.getElementById("employeeCode").value="";
  document.getElementById("result").classList.add("hidden");
  showMessage("");
  document.getElementById("employeeCode").focus();
});
